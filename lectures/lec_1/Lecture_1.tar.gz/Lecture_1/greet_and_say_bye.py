import COMP9021.Lectures.Lecture_1.greet

COMP9021.Lectures.Lecture_1.greet.hello('universe')
print('Bye now...')
