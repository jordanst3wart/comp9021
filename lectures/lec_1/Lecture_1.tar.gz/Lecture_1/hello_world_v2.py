def hello_world():
    print('Hello world!')
